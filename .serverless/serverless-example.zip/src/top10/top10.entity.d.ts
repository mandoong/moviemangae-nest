import { BaseEntity } from 'typeorm';
export declare class Top10 extends BaseEntity {
    id: number;
    movie_id: string;
    date: string;
    created_at: Date;
    updated_at: Date;
}
