import { Top10Repository } from './top10.repository';
import { MovieRepository } from '../movie/movie.repository';
export declare class Top10Service {
    private top10Repository;
    private movieRepository;
    constructor(top10Repository: Top10Repository, movieRepository: MovieRepository);
    getTop10Today(type: String): Promise<any[]>;
}
