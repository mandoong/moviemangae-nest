export declare class Top10Module {
}
