import { Repository } from 'typeorm';
import { Top10 } from './top10.entity';

export class Top10Repository extends Repository<Top10> {}
