"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Top10Service = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const top10_entity_1 = require("./top10.entity");
const top10_repository_1 = require("./top10.repository");
const dayjs = require("dayjs");
const movie_entity_1 = require("../movie/movie.entity");
const movie_repository_1 = require("../movie/movie.repository");
let Top10Service = class Top10Service {
    constructor(top10Repository, movieRepository) {
        this.top10Repository = top10Repository;
        this.movieRepository = movieRepository;
    }
    async getTop10Today() {
        const today = dayjs().add(-1, 'day').format('YYYY-MM-DD');
        const top10 = await this.top10Repository.findOne({
            where: { date: today },
        });
        const result = [];
        if (top10) {
            const movies = JSON.parse(top10.movie_id);
            while (movies.length > 0) {
                const q = movies.shift();
                const movie = await this.movieRepository.findOne({
                    where: { movieId: q },
                });
                if (movie) {
                    result.push(movie);
                }
            }
        }
        return result;
    }
};
Top10Service = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(top10_entity_1.Top10)),
    __param(1, (0, typeorm_1.InjectRepository)(movie_entity_1.Movie)),
    __metadata("design:paramtypes", [top10_repository_1.Top10Repository,
        movie_repository_1.MovieRepository])
], Top10Service);
exports.Top10Service = Top10Service;
//# sourceMappingURL=top10.service.js.map