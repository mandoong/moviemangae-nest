import { Top10Service } from './top10.service';
export declare class Top10Controller {
    private top10service;
    constructor(top10service: Top10Service);
    getTop10Today(): Promise<any[]>;
}
