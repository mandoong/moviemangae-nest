"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Top10Repository = void 0;
const typeorm_1 = require("typeorm");
class Top10Repository extends typeorm_1.Repository {
}
exports.Top10Repository = Top10Repository;
//# sourceMappingURL=top10.repository.js.map