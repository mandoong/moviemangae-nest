import { MovieActorLink } from '../movie_actor_link/movie_actor_link.entity';
import { BaseEntity } from 'typeorm';
export declare class Actor extends BaseEntity {
    id: number;
    name: string;
    movies: MovieActorLink[];
    created_at: Date;
}
