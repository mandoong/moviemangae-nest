import { ActorRepository } from './actor.repository';
export declare class ActorService {
    private actorRepository;
    constructor(actorRepository: ActorRepository);
}
