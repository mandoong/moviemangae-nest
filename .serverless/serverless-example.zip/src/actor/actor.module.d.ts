export declare class ActorModule {
}
