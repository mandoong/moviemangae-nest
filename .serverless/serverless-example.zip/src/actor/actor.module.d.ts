export declare class ActorModule {
}
