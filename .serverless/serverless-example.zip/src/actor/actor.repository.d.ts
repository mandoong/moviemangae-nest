import { Repository } from 'typeorm';
import { Actor } from './actor.entity';
export declare class ActorRepository extends Repository<Actor> {
}
