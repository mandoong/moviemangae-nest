import { ActorService } from './actor.service';
export declare class ActorController {
    private actorService;
    constructor(actorService: ActorService);
}
