import { Repository } from 'typeorm';
import { Actor } from './actor.entity';

export class ActorRepository extends Repository<Actor> {}
