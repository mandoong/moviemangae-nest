"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ActorRepository = void 0;
const typeorm_1 = require("typeorm");
class ActorRepository extends typeorm_1.Repository {
}
exports.ActorRepository = ActorRepository;
//# sourceMappingURL=actor.repository.js.map