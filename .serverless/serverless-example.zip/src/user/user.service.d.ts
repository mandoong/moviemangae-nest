import { User } from './user.entity';
import { UserRepository } from './user.repository';
export declare class UserService {
    private userRepository;
    constructor(userRepository: UserRepository);
    getAllUser(page: number): Promise<User[]>;
    getUser(id: number): Promise<User>;
    getMyLikeMovie(req: any): Promise<User>;
    getMyProfile(req: any): Promise<User>;
}
