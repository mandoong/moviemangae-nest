"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const user_entity_1 = require("./user.entity");
const user_repository_1 = require("./user.repository");
let UserService = class UserService {
    constructor(userRepository) {
        this.userRepository = userRepository;
    }
    async getAllUser(page) {
        const result = await this.userRepository.find({ take: 30, skip: page });
        return result;
    }
    async getUserCount() {
        const result = await this.userRepository.count();
        return result;
    }
    async getUser(id) {
        const result = await this.userRepository.findOne({ where: { id: id } });
        if (!result) {
            throw new common_1.NotFoundException('해당 유저를 찾을 수 없습니다.');
        }
        return result;
    }
    async getMyLikeMovie(req) {
        const user = this.userRepository
            .createQueryBuilder('user')
            .where('user.id = :id', { id: req.user.id })
            .leftJoinAndSelect('user.liked_movie', 'liked_movie', 'liked_movie.type = "likeMovie"')
            .leftJoinAndSelect('liked_movie.movie', 'likeMovie')
            .leftJoinAndSelect('user.disliked_movie', 'disliked_movie', 'disliked_movie.type = "dislikeMovie"')
            .leftJoinAndSelect('disliked_movie.movie', 'dislikeMovie')
            .getOne();
        return user;
    }
    async getMyProfile(req) {
        const { email } = req.user;
        const profile = await this.userRepository
            .createQueryBuilder('user')
            .where(`user.email = :email`, { email: email })
            .select(['user.id', 'user.email', 'user.name'])
            .leftJoinAndSelect('user.liked_movie', 'liked_movie', 'liked_movie.type = "likeMovie"')
            .leftJoinAndSelect('liked_movie.movie', 'likeMovie')
            .leftJoinAndSelect('user.disliked_movie', 'disliked_movie', 'disliked_movie.type = "dislikeMovie"')
            .leftJoinAndSelect('disliked_movie.movie', 'dislikeMovie')
            .leftJoinAndSelect('user.liked_comments', 'liked_comments', 'liked_comments.type = "comment"')
            .leftJoinAndSelect('liked_comments.comment', 'comment')
            .leftJoinAndSelect('comment.user', 'comment_user')
            .leftJoinAndSelect('user.comments', 'comments')
            .leftJoinAndSelect('user.best_movies', 'best_movies', 'best_movies.type = "bestMovie"')
            .leftJoinAndSelect('best_movies.movie', 'best_movie')
            .leftJoinAndSelect('user.view_movies', 'view_movies', 'view_movies.type = "viewMovie"')
            .leftJoinAndSelect('view_movies.movie', 'view_movie')
            .getOne();
        return profile;
    }
    async getUserById(id) {
        const profile = await this.userRepository
            .createQueryBuilder('user')
            .where(`user.id = :id`, { id: id })
            .select(['user.id', 'user.email', 'user.name'])
            .leftJoinAndSelect('user.liked_movie', 'liked_movie', 'liked_movie.type = "likeMovie"')
            .leftJoinAndSelect('liked_movie.movie', 'likeMovie')
            .leftJoinAndSelect('user.disliked_movie', 'disliked_movie', 'disliked_movie.type = "dislikeMovie"')
            .leftJoinAndSelect('disliked_movie.movie', 'dislikeMovie')
            .leftJoinAndSelect('user.liked_comments', 'liked_comments', 'liked_comments.type = "comment"')
            .leftJoinAndSelect('liked_comments.comment', 'comment')
            .leftJoinAndSelect('comment.user', 'comment_user')
            .leftJoinAndSelect('user.comments', 'comments')
            .leftJoinAndSelect('user.best_movies', 'best_movies', 'best_movies.type = "bestMovie"')
            .leftJoinAndSelect('best_movies.movie', 'best_movie')
            .leftJoinAndSelect('user.view_movies', 'view_movies', 'view_movies.type = "viewMovie"')
            .leftJoinAndSelect('view_movies.movie', 'view_movie')
            .getOne();
        return profile;
    }
};
UserService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [user_repository_1.UserRepository])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=user.service.js.map