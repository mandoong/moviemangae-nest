import { Comment } from '../comment/comment.entity';
import { MovieLikeLink } from '../movie_like_link/movie_like_link.entity';
import { BaseEntity } from 'typeorm';
export declare class User extends BaseEntity {
    id: number;
    email: string;
    password: string;
    name: string;
    liked_movie: MovieLikeLink[];
    disliked_movie: MovieLikeLink[];
    comments: Comment[];
    liked_comments: MovieLikeLink[];
    best_movies: MovieLikeLink[];
    view_movies: MovieLikeLink[];
    created_at: Date;
    updated_at: Date;
}
