import { UserService } from './user.service';
import { User } from './user.entity';
import { Request } from 'express';
export declare class UserController {
    private userService;
    constructor(userService: UserService);
    getAllUser(page: number): Promise<User[]>;
    getUser(id: number): Promise<User>;
    getMyProfile(req: Request): Promise<User>;
    getMyLikeMovie(req: Request): Promise<User>;
}
