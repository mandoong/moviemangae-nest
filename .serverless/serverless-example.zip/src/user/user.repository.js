"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRepository = void 0;
const typeorm_1 = require("typeorm");
class UserRepository extends typeorm_1.Repository {
}
exports.UserRepository = UserRepository;
//# sourceMappingURL=user.repository.js.map