"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommentService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const comment_entity_1 = require("./comment.entity");
const comment_repository_1 = require("./comment.repository");
const movie_like_link_entity_1 = require("../movie_like_link/movie_like_link.entity");
const movie_like_link_repository_1 = require("../movie_like_link/movie_like_link.repository");
const user_entity_1 = require("../user/user.entity");
const user_repository_1 = require("../user/user.repository");
const movie_entity_1 = require("../movie/movie.entity");
const movie_repository_1 = require("../movie/movie.repository");
let CommentService = class CommentService {
    constructor(commentRepository, movieLikeLinkRepository, movieRepository, userRepository) {
        this.commentRepository = commentRepository;
        this.movieLikeLinkRepository = movieLikeLinkRepository;
        this.movieRepository = movieRepository;
        this.userRepository = userRepository;
    }
    async getCommentsByMovieId(movie_id) {
        const result = await this.commentRepository.find({
            where: {
                movie_id: movie_id,
            },
            relations: { children: true, user: true },
        });
        return result;
    }
    async getCommentCount() {
        const result = await this.commentRepository.count();
        return result;
    }
    async getCommentById(id) {
        const result = await this.commentRepository.findOne({
            where: { id: id },
            relations: [
                'children',
                'children.user',
                'liked_user',
                'user',
                'comment_movie',
            ],
        });
        return result;
    }
    async getAllComment(page = 0) {
        const result = await this.commentRepository.find({
            skip: page * 30,
            take: 30,
            relations: {
                children: true,
                user: true,
                comment_movie: true,
                parent: true,
            },
        });
        return result;
    }
    async getMyComment(req) {
        const result = await this.commentRepository.find({
            where: { user: { id: req.user.id } },
            relations: {
                user: true,
                children: true,
                comment_movie: true,
                parent: true,
            },
        });
        return result;
    }
    async getMyBestComment(req) {
        const today = new Date();
        const result = await this.commentRepository.find({
            where: { user: { id: req.user.id } },
            relations: {
                user: true,
                children: true,
                comment_movie: true,
                parent: true,
            },
        });
        return result;
    }
    async createComments(commentCreateDto, req) {
        const { movie_id, depth, content, parent_id } = commentCreateDto;
        const user = await this.userRepository.findOne({
            where: { id: req.user.id },
        });
        const movie = await this.movieRepository.findOne({
            where: { id: movie_id },
            relations: ['comments', 'comments.user'],
        });
        if (depth === 0 && movie.comments.some((e) => e.user.id === req.user.id)) {
            throw new common_1.BadRequestException('이미 작성된 리뷰가 있습니다.');
        }
        const comment = new comment_entity_1.Comment();
        comment.movie_id = movie_id;
        comment.user = user;
        comment.depth = depth;
        comment.content = content;
        if (depth > 0) {
            const parentComment = await this.commentRepository.findOne({
                where: { id: parent_id },
                relations: { children: true },
            });
            comment.parent = parentComment;
            await this.commentRepository.save(parentComment);
        }
        movie.comments.push(comment);
        await this.commentRepository.save(comment);
        await this.movieRepository.save(movie);
        return comment;
    }
    async updateComment(id, content) {
        const comment = await this.commentRepository.findOne({ where: { id: id } });
        if (comment) {
            comment.content = content;
            await this.commentRepository.save(comment);
        }
        else {
            throw new common_1.NotFoundException('해당 댓글을 찾을 수 없습니다.');
        }
        return comment;
    }
    async deleteComment(id) {
        await this.commentRepository.delete(id);
    }
    async likeComment(id, req) {
        const comment = await this.commentRepository.findOne({
            where: {
                id: id,
            },
            relations: ['liked_user', 'liked_user.user'],
        });
        if (!comment) {
            throw new common_1.NotFoundException('해당 댓글을 찾을 수 없습니다.');
        }
        else if (comment.liked_user.some((e) => e.user.id === req.user.id)) {
            throw new common_1.BadRequestException('이미 좋아요를 하였습니다.');
        }
        const user = await this.userRepository.findOne({
            where: { id: req.user.id },
        });
        const link = new movie_like_link_entity_1.MovieLikeLink();
        link.comment = comment;
        link.user = user;
        link.type = 'comment';
        comment.like = comment.like + 1;
        await this.commentRepository.save(comment);
        await this.movieLikeLinkRepository.save(link);
        return comment;
    }
    async cancelLikeComment(id, req) {
        const comment = await this.commentRepository.findOne({
            where: { id: id },
        });
        if (!comment) {
            throw new common_1.NotFoundException('해당 댓글을 찾을 수 없습니다.');
        }
        const link = await this.movieLikeLinkRepository.findOne({
            where: {
                type: 'comment',
                comment: { id },
                user: { id: req.user.id },
            },
            relations: ['comment', 'user'],
        });
        if (!link) {
            throw new common_1.NotFoundException('해당 댓글에 좋아요 하지 않았습니다.');
        }
        comment.like = comment.like - 1;
        await this.commentRepository.save(comment);
        await this.movieLikeLinkRepository.delete(link.id);
        return comment;
    }
};
CommentService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(comment_entity_1.Comment)),
    __param(1, (0, typeorm_1.InjectRepository)(movie_like_link_entity_1.MovieLikeLink)),
    __param(2, (0, typeorm_1.InjectRepository)(movie_entity_1.Movie)),
    __param(3, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [comment_repository_1.CommentRepository,
        movie_like_link_repository_1.MovieLikeLinkRepository,
        movie_repository_1.MovieRepository,
        user_repository_1.UserRepository])
], CommentService);
exports.CommentService = CommentService;
//# sourceMappingURL=comment.service.js.map