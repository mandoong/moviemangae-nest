export declare class CommentCreateDto {
    movie_id: number;
    depth: number;
    parent_id: number;
    content: string;
}
