import { Comment } from './comment.entity';
import { CommentRepository } from './comment.repository';
import { CommentCreateDto } from './dto/comment.create.dto';
import { MovieLikeLinkRepository } from '../movie_like_link/movie_like_link.repository';
import { UserRepository } from '../user/user.repository';
import { MovieRepository } from '../movie/movie.repository';
export declare class CommentService {
    private commentRepository;
    private movieLikeLinkRepository;
    private movieRepository;
    private userRepository;
    constructor(commentRepository: CommentRepository, movieLikeLinkRepository: MovieLikeLinkRepository, movieRepository: MovieRepository, userRepository: UserRepository);
    getCommentsByMovieId(movie_id: number): Promise<Comment[]>;
    getCommentCount(): Promise<number>;
    getCommentById(id: number): Promise<Comment>;
    getAllComment(page?: number): Promise<Comment[]>;
    getMyComment(req: any): Promise<Comment[]>;
    getBestComment(): Promise<Comment[]>;
    createComments(commentCreateDto: CommentCreateDto, req: any): Promise<Comment>;
    updateComment(id: number, content: string): Promise<Comment>;
    deleteComment(id: number): Promise<void>;
    likeComment(id: number, req: any): Promise<Comment>;
    cancelLikeComment(id: number, req: any): Promise<Comment>;
}
