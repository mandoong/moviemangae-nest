export declare class CommentModule {
}
