export declare class CommentModule {
}
