import { Movie } from '../movie/movie.entity';
import { MovieLikeLink } from '../movie_like_link/movie_like_link.entity';
import { User } from '../user/user.entity';
import { BaseEntity } from 'typeorm';
export declare class Comment extends BaseEntity {
    id: number;
    movie_id: number;
    user: User;
    content: string;
    like: number;
    report: number;
    children: Comment[];
    parent: Comment;
    depth: number;
    liked_user: MovieLikeLink[];
    comment_movie: Movie;
    created_at: Date;
    updated_at: Date;
}
