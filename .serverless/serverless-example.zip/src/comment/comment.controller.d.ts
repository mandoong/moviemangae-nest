import { CommentService } from './comment.service';
import { CommentCreateDto } from './dto/comment.create.dto';
import { Request } from 'express';
export declare class CommentController {
    private commentService;
    constructor(commentService: CommentService);
    getAllComment(page: number): Promise<import("./comment.entity").Comment[]>;
    getCommentCount(): Promise<number>;
    getComments(id: number): Promise<import("./comment.entity").Comment[]>;
    deleteComment(id: number): Promise<void>;
    createComment(commentCreateDto: CommentCreateDto, req: Request): Promise<import("./comment.entity").Comment>;
    getMyComment(req: any): Promise<import("./comment.entity").Comment[]>;
    likeComment(id: number, req: any): Promise<import("./comment.entity").Comment>;
    cancelLikeComment(id: number, req: any): Promise<import("./comment.entity").Comment>;
}
