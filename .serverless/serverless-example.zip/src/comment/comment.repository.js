"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CommentRepository = void 0;
const typeorm_1 = require("typeorm");
class CommentRepository extends typeorm_1.Repository {
}
exports.CommentRepository = CommentRepository;
//# sourceMappingURL=comment.repository.js.map