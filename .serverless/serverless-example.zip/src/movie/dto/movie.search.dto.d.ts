export declare class MovieSearchDto {
    page: number;
    platform: string[];
    like: string;
    genre: string[];
    scoring: number[];
    duration: string;
    dataCreated: Date;
    presentationType: string[];
}
