"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MovieRepository = void 0;
const typeorm_1 = require("typeorm");
class MovieRepository extends typeorm_1.Repository {
}
exports.MovieRepository = MovieRepository;
//# sourceMappingURL=movie.repository.js.map