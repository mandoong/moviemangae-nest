import { Movie } from './movie.entity';
import { MovieRepository } from './movie.repository';
import { MovieLikeLinkRepository } from '../movie_like_link/movie_like_link.repository';
import { MovieActorLinkRepository } from '../movie_actor_link/movie_actor_link.repository';
import { MovieSearchDto } from './dto/movie.search.dto';
import { UserRepository } from '../user/user.repository';
export declare class MovieService {
    private movieRepository;
    private movieActorLinkRepository;
    private userRepository;
    private movieLikeLinkRepository;
    constructor(movieRepository: MovieRepository, movieActorLinkRepository: MovieActorLinkRepository, userRepository: UserRepository, movieLikeLinkRepository: MovieLikeLinkRepository);
    getMovieCount(): Promise<number>;
    getAllMovie(page?: number): Promise<Movie[]>;
    getMovieSelect(movieDto: MovieSearchDto): Promise<Movie[]>;
    getMovieOne(id: number, req: any): Promise<Movie>;
    searchMovie(word: string): Promise<Movie[]>;
    getDeadlineMovies(): Promise<Movie[]>;
    getFavoriteMovies(): Promise<Movie[]>;
    addMyMovieList(id: number, req: any, type: string): Promise<Movie>;
    removeMyMovieList(id: number, req: any, type: string): Promise<Movie>;
}
