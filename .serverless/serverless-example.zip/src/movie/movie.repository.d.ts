import { Repository } from 'typeorm';
import { Movie } from './movie.entity';
export declare class MovieRepository extends Repository<Movie> {
}
