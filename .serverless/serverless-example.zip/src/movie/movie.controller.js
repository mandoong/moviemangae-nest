"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MovieController = void 0;
const common_1 = require("@nestjs/common");
const movie_service_1 = require("./movie.service");
const movie_search_dto_1 = require("./dto/movie.search.dto");
const common_2 = require("@nestjs/common");
const passport_1 = require("@nestjs/passport");
let MovieController = class MovieController {
    constructor(movieService) {
        this.movieService = movieService;
    }
    getAllMovie(page) {
        return this.movieService.getAllMovie(page);
    }
    getMovieById(id, req) {
        return this.movieService.getMovieOne(id, req);
    }
    getSearchMovie(word) {
        return this.movieService.searchMovie(word);
    }
    getFavoriteMovies() {
        return this.movieService.getFavoriteMovies();
    }
    getDeadlineMovies() {
        return this.movieService.getDeadlineMovies();
    }
    getMovieCount() {
        return this.movieService.getMovieCount();
    }
    getMovieSelect(dto) {
        return this.movieService.getMovieSelect(dto);
    }
    addMyMovieList(id, req, type) {
        return this.movieService.addMyMovieList(id, req, type);
    }
    removeMyMovieList(id, req, type) {
        return this.movieService.removeMyMovieList(id, req, type);
    }
};
__decorate([
    (0, common_1.Get)('/all'),
    __param(0, (0, common_1.Query)('page')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], MovieController.prototype, "getAllMovie", null);
__decorate([
    (0, common_1.Get)('/find/:id'),
    (0, common_2.UseGuards)((0, passport_1.AuthGuard)()),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "getMovieById", null);
__decorate([
    (0, common_1.Get)('/search'),
    __param(0, (0, common_1.Query)('word')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "getSearchMovie", null);
__decorate([
    (0, common_1.Get)('/favorite'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "getFavoriteMovies", null);
__decorate([
    (0, common_1.Get)('/deadline'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "getDeadlineMovies", null);
__decorate([
    (0, common_1.Get)('/count'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "getMovieCount", null);
__decorate([
    (0, common_1.Post)('/select'),
    __param(0, (0, common_1.Body)('dto')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [movie_search_dto_1.MovieSearchDto]),
    __metadata("design:returntype", Promise)
], MovieController.prototype, "getMovieSelect", null);
__decorate([
    (0, common_1.Post)('/:id/like/'),
    (0, common_2.UseGuards)((0, passport_1.AuthGuard)()),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Body)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "addMyMovieList", null);
__decorate([
    (0, common_1.Delete)('/:id/like'),
    (0, common_2.UseGuards)((0, passport_1.AuthGuard)()),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.Body)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, String]),
    __metadata("design:returntype", void 0)
], MovieController.prototype, "removeMyMovieList", null);
MovieController = __decorate([
    (0, common_1.Controller)('movies'),
    __metadata("design:paramtypes", [movie_service_1.MovieService])
], MovieController);
exports.MovieController = MovieController;
//# sourceMappingURL=movie.controller.js.map