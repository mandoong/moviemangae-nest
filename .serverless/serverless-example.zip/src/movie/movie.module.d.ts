export declare class MovieModule {
}
