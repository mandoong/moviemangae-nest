export declare class MovieModule {
}
