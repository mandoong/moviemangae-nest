import { MovieService } from './movie.service';
import { Movie } from './movie.entity';
import { MovieSearchDto } from './dto/movie.search.dto';
import { Request } from 'express';
export declare class MovieController {
    private movieService;
    constructor(movieService: MovieService);
    getAllMovie(page: number): Promise<Movie[]>;
    getMovieById(id: number, req: Request): Promise<Movie>;
    getSearchMovie(word: string): Promise<Movie[]>;
    getFavoriteMovies(): Promise<Movie[]>;
    getDeadlineMovies(): Promise<Movie[]>;
    getMovieCount(): Promise<number>;
    getMovieSelect(dto: MovieSearchDto): Promise<Movie[]>;
    addMyMovieList(id: number, req: Request, type: string): Promise<Movie>;
    removeMyMovieList(id: number, req: Request, type: string): Promise<Movie>;
}
