export declare class MovieActorLinkModule {
}
