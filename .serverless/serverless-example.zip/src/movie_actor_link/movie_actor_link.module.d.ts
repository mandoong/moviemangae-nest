export declare class MovieActorLinkModule {
}
