"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MovieActorLinkRepository = void 0;
const typeorm_1 = require("typeorm");
class MovieActorLinkRepository extends typeorm_1.Repository {
}
exports.MovieActorLinkRepository = MovieActorLinkRepository;
//# sourceMappingURL=movie_actor_link.repository.js.map