import { Repository } from 'typeorm';
import { MovieActorLink } from './movie_actor_link.entity';
export declare class MovieActorLinkRepository extends Repository<MovieActorLink> {
}
