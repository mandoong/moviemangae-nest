import { MovieActorLinkRepository } from './movie_actor_link.repository';
import { ActorRepository } from '../actor/actor.repository';
export declare class MovieActorLinkService {
    private movieActorLinkRepository;
    private actorRepository;
    constructor(movieActorLinkRepository: MovieActorLinkRepository, actorRepository: ActorRepository);
    getActor(): void;
}
