import { MovieActorLinkService } from './movie_actor_link.service';
export declare class MovieActorLinkController {
    private movieActorLinkService;
    constructor(movieActorLinkService: MovieActorLinkService);
}
