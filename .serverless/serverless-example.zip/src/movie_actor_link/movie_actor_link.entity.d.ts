import { Actor } from '../actor/actor.entity';
import { Movie } from '../movie/movie.entity';
import { BaseEntity } from 'typeorm';
export declare class MovieActorLink extends BaseEntity {
    id: number;
    movie: Movie;
    actor: Actor;
    character: string;
    created_at: Date;
}
