/// <reference types="qs" />
import { AuthService } from './auth.service';
import { Request } from 'express';
export declare class AuthController {
    private readonly authService;
    oauth2Client: any;
    constructor(authService: AuthService);
    hi(): Promise<any>;
    log(): Promise<void>;
    loginGoogleRedirect(req: Request): Promise<{
        query: import("qs").ParsedQs;
        user: import("googleapis").oauth2_v2.Schema$Userinfo;
    }>;
}
