import { AuthService } from './auth.service';
import { UserService } from '../user/user.service';
import { Request, Response } from 'express';
export declare class AuthController {
    private readonly authService;
    private readonly userService;
    constructor(authService: AuthService, userService: UserService);
    loginGoogle(req: Request, res: Response): Promise<void>;
    log(): Promise<void>;
    loginGoogleRedirect(req: Request, res: Response): Promise<void>;
    loginNaver(req: Request, res: Response): Promise<void>;
    loginKakao(req: Request, res: Response): Promise<void>;
}
