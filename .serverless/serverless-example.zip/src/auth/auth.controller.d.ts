/// <reference types="qs" />
import { AuthService } from './auth.service';
import { Request, Response } from 'express';
export declare class AuthController {
    private readonly authService;
    oauth2Client: any;
    constructor(authService: AuthService);
    hi(): Promise<any>;
    log(): Promise<void>;
    loginGoogleRedirect(req: Request): Promise<{
        query: import("qs").ParsedQs;
        user: import("googleapis").oauth2_v2.Schema$Userinfo;
    }>;
    loginGoole(req: any, res: any): Promise<import("../user/user.entity").User>;
    loginNaver(req: any, res: any): Promise<import("../user/user.entity").User>;
    loginKakao(req: Request, res: Response): Promise<void>;
}
