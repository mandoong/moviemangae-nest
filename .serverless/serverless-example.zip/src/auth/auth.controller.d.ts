import { AuthService } from './auth.service';
import { Request } from 'express';
export declare class AuthController {
    private readonly authService;
    constructor(authService: AuthService);
    loginGoole(req: any): Promise<any>;
    loginNaver(req: any): Promise<any>;
    loginKakao(req: Request): Promise<any>;
    loginLocal(email: any, name: any): Promise<string>;
}
