import { User } from '../user/user.entity';
import { Repository } from 'typeorm';
import { AuthCredentialDto } from './dto/user.auth-credential.dto';
import { JwtService } from '@nestjs/jwt';
export declare class AuthService {
    private userRepository;
    private jwtService;
    constructor(userRepository: Repository<User>, jwtService: JwtService);
    SignUp(authCredentialDto: AuthCredentialDto): Promise<void>;
    SignIn(authCredentialDto: AuthCredentialDto): Promise<{
        accessToken: string;
    }>;
    OAuthLogin(req: any, res: any): Promise<User>;
}
