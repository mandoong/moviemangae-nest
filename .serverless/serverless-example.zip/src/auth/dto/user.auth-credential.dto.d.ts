export declare class AuthCredentialDto {
    email: string;
    password: string;
    name: string;
}
