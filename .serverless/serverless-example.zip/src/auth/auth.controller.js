"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthController = void 0;
const common_1 = require("@nestjs/common");
const auth_service_1 = require("./auth.service");
const googleapis_1 = require("googleapis");
let AuthController = class AuthController {
    constructor(authService) {
        this.authService = authService;
        this.oauth2Client = new googleapis_1.google.auth.OAuth2('1018839334367-qtgmojd5mkdi724mq0hinkm02rc1t99c.apps.googleusercontent.com', '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', 'https://oqwc40fv0b.execute-api.ap-northeast-2.amazonaws.com/dev/auth/login/google-redirect');
    }
    async hi() {
        const scopes = [
            'https://www.googleapis.com/auth/userinfo.profile',
            'https://www.googleapis.com/auth/userinfo.email',
        ];
        const url = this.oauth2Client.generateAuthUrl({
            access_type: 'offline',
            scope: scopes,
        });
        return url;
    }
    async log() { }
    async loginGoogleRedirect(req) {
        const { tokens } = await this.oauth2Client.getToken(req.query.code);
        this.oauth2Client.setCredentials({ access_token: tokens.access_token });
        const oauth2 = googleapis_1.google.oauth2({
            auth: this.oauth2Client,
            version: 'v2',
        });
        const { data } = await oauth2.userinfo.get();
        return {
            query: req.query,
            user: data,
        };
    }
};
__decorate([
    (0, common_1.Get)('login/google'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "hi", null);
__decorate([
    (0, common_1.Get)('/login/hello'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "log", null);
__decorate([
    (0, common_1.Get)('/login/google-redirect'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], AuthController.prototype, "loginGoogleRedirect", null);
AuthController = __decorate([
    (0, common_1.Controller)('/auth'),
    __metadata("design:paramtypes", [auth_service_1.AuthService])
], AuthController);
exports.AuthController = AuthController;
//# sourceMappingURL=auth.controller.js.map