"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MovieLikeLinkRepository = void 0;
const typeorm_1 = require("typeorm");
class MovieLikeLinkRepository extends typeorm_1.Repository {
}
exports.MovieLikeLinkRepository = MovieLikeLinkRepository;
//# sourceMappingURL=movie_like_link.repository.js.map