import { Repository } from 'typeorm';
import { MovieLikeLink } from './movie_like_link.entity';
export declare class MovieLikeLinkRepository extends Repository<MovieLikeLink> {
}
