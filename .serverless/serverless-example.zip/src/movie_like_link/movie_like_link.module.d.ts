export declare class MovieLikeLinkModule {
}
