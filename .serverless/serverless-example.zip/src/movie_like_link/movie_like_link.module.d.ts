export declare class MovieLikeLinkModule {
}
