import { MovieLikeLinkService } from './movie_like_link.service';
export declare class MovieLikeLinkController {
    private movieLikeLinkService;
    constructor(movieLikeLinkService: MovieLikeLinkService);
}
