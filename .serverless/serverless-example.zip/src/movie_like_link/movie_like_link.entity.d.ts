import { Comment } from '../comment/comment.entity';
import { Movie } from '../movie/movie.entity';
import { User } from '../user/user.entity';
import { BaseEntity } from 'typeorm';
export declare class MovieLikeLink extends BaseEntity {
    id: number;
    movie: Movie;
    comment: Comment;
    user: User;
    type: string;
    created_at: Date;
}
