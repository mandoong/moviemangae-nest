import { MovieLikeLinkRepository } from './movie_like_link.repository';
import { UserRepository } from '../user/user.repository';
export declare class MovieLikeLinkService {
    private movieLikeLinkRepository;
    private userRepository;
    constructor(movieLikeLinkRepository: MovieLikeLinkRepository, userRepository: UserRepository);
    MovieLikeUser(): Promise<void>;
}
