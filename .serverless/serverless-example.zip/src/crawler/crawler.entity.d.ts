import { BaseEntity } from 'typeorm';
export declare class Crawler extends BaseEntity {
    id: number;
    movieId: string;
    content: string;
    created_at: Date;
}
