import { Repository } from 'typeorm';
import { Crawler } from './crawler.entity';
export declare class CrawlerRepository extends Repository<Crawler> {
}
