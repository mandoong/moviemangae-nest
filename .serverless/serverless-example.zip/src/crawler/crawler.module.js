"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerModule = void 0;
const common_1 = require("@nestjs/common");
const movie_entity_1 = require("../movie/movie.entity");
const movie_repository_1 = require("../movie/movie.repository");
const typeorm_1 = require("@nestjs/typeorm");
const crawler_service_1 = require("./crawler.service");
const crawler_controller_1 = require("./crawler.controller");
const crawler_repository_1 = require("./crawler.repository");
const crawler_entity_1 = require("./crawler.entity");
const actor_entity_1 = require("../actor/actor.entity");
const actor_repository_1 = require("../actor/actor.repository");
const movie_actor_link_entity_1 = require("../movie_actor_link/movie_actor_link.entity");
const movie_actor_link_repository_1 = require("../movie_actor_link/movie_actor_link.repository");
const top10_entity_1 = require("../top10/top10.entity");
const top10_repository_1 = require("../top10/top10.repository");
let CrawlerModule = class CrawlerModule {
};
CrawlerModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([
                crawler_entity_1.Crawler,
                movie_entity_1.Movie,
                actor_entity_1.Actor,
                movie_actor_link_entity_1.MovieActorLink,
                crawler_repository_1.CrawlerRepository,
                movie_repository_1.MovieRepository,
                actor_repository_1.ActorRepository,
                movie_actor_link_repository_1.MovieActorLinkRepository,
                top10_entity_1.Top10,
                top10_repository_1.Top10Repository,
            ]),
        ],
        controllers: [crawler_controller_1.CrawlerController],
        providers: [crawler_service_1.CrawlerService],
    })
], CrawlerModule);
exports.CrawlerModule = CrawlerModule;
//# sourceMappingURL=crawler.module.js.map