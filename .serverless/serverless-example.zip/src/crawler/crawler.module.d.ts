export declare class CrawlerModule {
}
