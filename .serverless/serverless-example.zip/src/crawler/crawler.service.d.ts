import { Movie } from '../movie/movie.entity';
import { CrawlerRepository } from './crawler.repository';
import { MovieRepository } from '../movie/movie.repository';
import { ActorRepository } from '../actor/actor.repository';
import { MovieActorLinkRepository } from '../movie_actor_link/movie_actor_link.repository';
import { Top10Repository } from '../top10/top10.repository';
export declare class CrawlerService {
    private crawlerRepository;
    private movieRepository;
    private actorRepository;
    private movieActorLinkRepository;
    private top10Repository;
    constructor(crawlerRepository: CrawlerRepository, movieRepository: MovieRepository, actorRepository: ActorRepository, movieActorLinkRepository: MovieActorLinkRepository, top10Repository: Top10Repository);
    getHeaders(): {
        headers: {
            'user-agent': string;
        };
    };
    getMovieData(): Promise<void>;
    getActor(actors: any, movie: Movie): Promise<string>;
    refineCrawlerData(): Promise<any[]>;
    getTop10Movies(): Promise<any[]>;
}
