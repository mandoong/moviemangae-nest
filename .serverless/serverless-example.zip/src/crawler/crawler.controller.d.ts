import { CrawlerService } from './crawler.service';
export declare class CrawlerController {
    private crawlerService;
    constructor(crawlerService: CrawlerService);
    getCrawlerData(): Promise<void>;
    refineCrawlerData(): Promise<any[]>;
    getTop10Movies(): Promise<any[]>;
}
