import { Repository } from 'typeorm';
import { Crawler } from './crawler.entity';

export class CrawlerRepository extends Repository<Crawler> {}
