"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CrawlerRepository = void 0;
const typeorm_1 = require("typeorm");
class CrawlerRepository extends typeorm_1.Repository {
}
exports.CrawlerRepository = CrawlerRepository;
//# sourceMappingURL=crawler.repository.js.map